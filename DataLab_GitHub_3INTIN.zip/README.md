# 🧠 DataLab — Os Organizadores de Dados

**Mini laboratório interativo de JavaScript | 3º INTIN · Grupo 5**

Aprenda **arrays, índices, `.length`, `.push()` e objetos literais** com exemplos visuais, atividades práticas e um quiz. O DataLab foi criado para o seminário de **Lógica e Interatividade**, em linguagem acessível ao Ensino Médio Técnico em Informática.

![Prévia do DataLab](assets/images/preview.webp)

## ✨ O que o site oferece?

| Módulo | O que você aprende | O que você faz |
|---|---|---|
| **Conceitos** | Arrays, índices e objetos | Consulta explicações e exemplos |
| **Laboratório de arrays** | `[]`, índices, `.length`, `.push()` | Seleciona elementos e adiciona itens |
| **Laboratório de objetos** | `{}`, chave, valor, propriedades | Edita a ficha de um aluno |
| **Missão de cadastro** | Arrays de objetos e `push()` | Cadastra alunos com nome e nota |
| **Quiz final** | Revisão do conteúdo | Responde 4 questões com feedback imediato |

## 📁 Estrutura do projeto

```text
DataLab_GitHub_3INTIN/
├── index.html                 # Estrutura da página
├── assets/
│   ├── css/
│   │   └── style.css          # Estilos e responsividade
│   ├── js/
│   │   └── app.js             # Interatividade e lógica
│   └── images/
│       ├── favicon.svg        # Ícone da página
│       ├── preview.webp       # Captura de tela do projeto
│       └── mobile.webp        # Captura de tela no celular
├── GUIA_DE_APRESENTACAO.md    # Roteiro para os 4 integrantes
├── .gitignore
├── .nojekyll
└── README.md
```

## ▶️ Como executar

**Opção 1 — Sem instalar nada:** baixe os arquivos e abra `index.html` no navegador.

**Opção 2 — VS Code:** abra a pasta do projeto e execute `index.html` com a extensão *Live Server*, caso tenha instalado.

Não há dependências externas, banco de dados ou compilação. O site funciona **sem internet**.

## 🌐 Como publicar no GitHub Pages

1. No [GitHub](https://github.com/), crie um repositório, por exemplo, `datalab-3intin`.
2. Envie **todos os arquivos e pastas** deste projeto. O `index.html` deve ficar na **raiz** do repositório, e não dentro de uma pasta adicional.
3. Abra **Settings → Pages** no repositório.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta **`/(root)`**. Clique em **Save**.
6. Após a publicação, a página terá um endereço semelhante a:

   `https://SEU-USUARIO.github.io/datalab-3intin/`

> Esse endereço é apenas um exemplo: substitua `SEU-USUARIO` e `datalab-3intin` pelos valores reais do seu GitHub. A publicação não foi feita automaticamente.

### Enviar pelo terminal (alternativa)

Crie previamente um repositório vazio no GitHub e, dentro desta pasta, execute:

```bash
git init
git add .
git commit -m "Adiciona DataLab do 3º INTIN"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/datalab-3intin.git
git push -u origin main
```

## 🧩 Um pouco do JavaScript

```javascript
const frutas = ['Maçã', 'Banana', 'Uva'];
console.log(frutas[0]);     // Maçã: primeiro elemento tem índice 0
console.log(frutas.length);  // 3
frutas.push('Kiwi');         // Adiciona ao final

const aluno = { nome: 'Ana', idade: 17, turma: '3º INTIN' };
console.log(aluno.nome);     // Ana

const alunos = [];
alunos.push({ nome: 'Pedro', nota: 8.5 });
```

Os campos inseridos pelos visitantes são exibidos como texto, sem usar `innerHTML` com entrada do usuário. Os cadastros da demonstração existem apenas enquanto a página está aberta; **não são enviados a um servidor**.

## 📱 Compatibilidade

- Layout adaptado para computador e celular.
- Navegação por teclado e respeito à preferência de movimento reduzido.
- Funciona nos navegadores modernos, inclusive hospedado em GitHub Pages.

![Prévia da versão mobile](assets/images/mobile.webp)

## 👥 Equipe — Grupo 5 | 3º INTIN

- Carlos André de Sousa Júnior
- Carlos Antônio Abreu de Oliveira
- Gabriel de Souza Oliveira
- Jéssica Esteffany Olimpio Simão Mederios

**Disciplina:** Lógica e Interatividade  
**Tema:** Os Organizadores de Dados — Arrays e Objetos Básicos em JavaScript

---

> **Uso didático:** projeto preparado como material complementar para a apresentação. A atividade sem telas, exigida no Pilar 2, deve ser feita separadamente com materiais analógicos.
