# 🎤 Roteiro rápido para o seminário — DataLab

O DataLab é uma ferramenta **digital complementar** para mostrar na prática os conteúdos do **Pilar 1**. Para o Pilar 2, sigam a atividade analógica (HQ em cartolina), que deve ser realizada sem computadores ou telas.

## Divisão sugerida entre os quatro integrantes

| Apresentador | Demonstração | Duração sugerida |
|---|---|---:|
| Carlos André | Apresenta o projeto e explica o que é um array | 1 minuto |
| Carlos Antônio | Clica nos índices e demonstra `.length` e `.push()` | 2 minutos |
| Gabriel | Edita o objeto literal de um aluno | 1 minuto |
| Jéssica | Cadastra 3 estudantes e conduz o quiz | 3 minutos |

**Duração total aproximada:** 7 minutos. Ajustem conforme o tempo reservado ao exemplo prático do Pilar 1.

## Ordem da demonstração

1. **Apresente o DataLab:** diga que é um laboratório para enxergar o código funcionando.
2. **Array:** selecione `Maçã` e mostre que o primeiro índice é **0**.
3. **`.length`:** destaque que o valor representa a quantidade de elementos, não o último índice.
4. **`.push()`:** adicione `Kiwi` e mostre a nova posição e o novo tamanho.
5. **Objeto:** altere nome, idade e turma de um aluno; compare com a estrutura `{ nome: '...', idade: ... }`.
6. **Missão:** cadastre três alunos. Explique que cada aluno é um objeto armazenado dentro de um array.
7. **Quiz:** convide a turma a responder e discuta o resultado.

## Materiais necessários

- Computador com um navegador moderno e, se possível, projetor.
- Arquivos do projeto baixados antes da apresentação.
- Para o **Pilar 2**, cartolina, papel, canetinhas, post-its e os outros materiais físicos exigidos pela atividade.

## Dica

O projeto não precisa de internet. Abra `index.html` antes do seminário e teste os botões.
